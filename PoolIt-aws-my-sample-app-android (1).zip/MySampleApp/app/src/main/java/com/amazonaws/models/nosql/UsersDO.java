package com.amazonaws.models.nosql;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "poolit-mobilehub-8986227-Users")

public class UsersDO {
    private String _userId;
    private String _bankInfo;
    private List<String> _events;
    private List<String> _friends;
    private String _password;
    private Double _score;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBAttribute(attributeName = "bankInfo")
    public String getBankInfo() {
        return _bankInfo;
    }

    public void setBankInfo(final String _bankInfo) {
        this._bankInfo = _bankInfo;
    }
    @DynamoDBAttribute(attributeName = "events")
    public List<String> getEvents() {
        return _events;
    }

    public void setEvents(final List<String> _events) {
        this._events = _events;
    }
    @DynamoDBAttribute(attributeName = "friends")
    public List<String> getFriends() {
        return _friends;
    }

    public void setFriends(final List<String> _friends) {
        this._friends = _friends;
    }
    @DynamoDBAttribute(attributeName = "password")
    public String getPassword() {
        return _password;
    }

    public void setPassword(final String _password) {
        this._password = _password;
    }
    @DynamoDBAttribute(attributeName = "score")
    public Double getScore() {
        return _score;
    }

    public void setScore(final Double _score) {
        this._score = _score;
    }

}
